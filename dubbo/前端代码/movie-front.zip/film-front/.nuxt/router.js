import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _23b01433 = () => import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */).then(m => m.default || m)
const _a46c0688 = () => import('..\\pages\\xseats.vue' /* webpackChunkName: "pages_xseats" */).then(m => m.default || m)
const _65f2282e = () => import('..\\pages\\xseats\\_id.vue' /* webpackChunkName: "pages_xseats__id" */).then(m => m.default || m)
const _6f504446 = () => import('..\\pages\\filmItem.vue' /* webpackChunkName: "pages_filmItem" */).then(m => m.default || m)
const _0638d3ad = () => import('..\\pages\\filmItem\\_id.vue' /* webpackChunkName: "pages_filmItem__id" */).then(m => m.default || m)
const _19aeac1a = () => import('..\\pages\\profile.vue' /* webpackChunkName: "pages_profile" */).then(m => m.default || m)
const _4a676d39 = () => import('..\\pages\\films.vue' /* webpackChunkName: "pages_films" */).then(m => m.default || m)
const _46ab4c97 = () => import('..\\pages\\cinema.vue' /* webpackChunkName: "pages_cinema" */).then(m => m.default || m)
const _763f8933 = () => import('..\\pages\\cinema\\_id.vue' /* webpackChunkName: "pages_cinema__id" */).then(m => m.default || m)
const _2a6d0d30 = () => import('..\\pages\\board.vue' /* webpackChunkName: "pages_board" */).then(m => m.default || m)
const _1e777612 = () => import('..\\pages\\query.vue' /* webpackChunkName: "pages_query" */).then(m => m.default || m)
const _6afe8469 = () => import('..\\pages\\query\\_kw.vue' /* webpackChunkName: "pages_query__kw" */).then(m => m.default || m)
const _a55e3e28 = () => import('..\\pages\\myorder.vue' /* webpackChunkName: "pages_myorder" */).then(m => m.default || m)
const _7460986e = () => import('..\\pages\\register.vue' /* webpackChunkName: "pages_register" */).then(m => m.default || m)
const _1db9aef9 = () => import('..\\pages\\news.vue' /* webpackChunkName: "pages_news" */).then(m => m.default || m)
const _72d33198 = () => import('..\\pages\\order.vue' /* webpackChunkName: "pages_order" */).then(m => m.default || m)
const _dc18c65c = () => import('..\\pages\\order\\_id.vue' /* webpackChunkName: "pages_order__id" */).then(m => m.default || m)
const _db2c3128 = () => import('..\\pages\\cinemas.vue' /* webpackChunkName: "pages_cinemas" */).then(m => m.default || m)
const _5a08711c = () => import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/login",
			component: _23b01433,
			name: "login"
		},
		{
			path: "/xseats",
			component: _a46c0688,
			name: "xseats",
			children: [
				{
					path: ":id?",
					component: _65f2282e,
					name: "xseats-id"
				}
			]
		},
		{
			path: "/filmItem",
			component: _6f504446,
			name: "filmItem",
			children: [
				{
					path: ":id?",
					component: _0638d3ad,
					name: "filmItem-id"
				}
			]
		},
		{
			path: "/profile",
			component: _19aeac1a,
			name: "profile"
		},
		{
			path: "/films",
			component: _4a676d39,
			name: "films"
		},
		{
			path: "/cinema",
			component: _46ab4c97,
			name: "cinema",
			children: [
				{
					path: ":id?",
					component: _763f8933,
					name: "cinema-id"
				}
			]
		},
		{
			path: "/board",
			component: _2a6d0d30,
			name: "board"
		},
		{
			path: "/query",
			component: _1e777612,
			name: "query",
			children: [
				{
					path: ":kw?",
					component: _6afe8469,
					name: "query-kw"
				}
			]
		},
		{
			path: "/myorder",
			component: _a55e3e28,
			name: "myorder"
		},
		{
			path: "/register",
			component: _7460986e,
			name: "register"
		},
		{
			path: "/news",
			component: _1db9aef9,
			name: "news"
		},
		{
			path: "/order",
			component: _72d33198,
			name: "order",
			children: [
				{
					path: ":id?",
					component: _dc18c65c,
					name: "order-id"
				}
			]
		},
		{
			path: "/cinemas",
			component: _db2c3128,
			name: "cinemas"
		},
		{
			path: "/",
			component: _5a08711c,
			name: "index"
		}
    ],
    
    
    fallback: false
  })
}
