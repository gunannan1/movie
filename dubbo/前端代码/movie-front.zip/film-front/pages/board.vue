<template>
  <div>
    <h1>board</h1>
  </div>
</template>
<style>

</style>
<script>

</script>
